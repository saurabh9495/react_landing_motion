import React from "react";
import { enquireScreen } from "enquire-js";
import "../App.css";

import Nav0 from "./Nav0";
import Banner0 from "./Banner0";
import Content0 from "./Content0";
import Content5 from "./Content5";
import Content3 from "./Content3";
import Footer1 from "./Footer1";

import {
  Nav00DataSource,
  Banner01DataSource,
  Content00DataSource,
  Content50DataSource,
  Content30DataSource,
  Footer10DataSource
} from "./data.source";
import "./less/antMotionStyle.less";

// import Card from "@material-ui/core/Card";
// import CardContent from "@material-ui/core/CardContent";
// import Typography from "@material-ui/core/Typography";
// import Grid from "@material-ui/core/Grid";

import {
  EditOutlined,
  EllipsisOutlined,
  SettingOutlined
} from "@ant-design/icons";

import { Layout } from "antd";
import { Card, Col, Row } from "antd";
import { Descriptions, Badge } from "antd";
import { Modal, Button } from "antd";

const { Content } = Layout;
const { Meta } = Card;

let isMobile;
enquireScreen(b => {
  isMobile = b;
});

const { location = {} } = typeof window !== "undefined" ? window : {};

export default class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile,
      show: !location.port,
      posts: [],
      loading: false,
      visible: false
    };
  }

  componentDidMount() {
    // fetch("https://akreddy.serveblog.net/wp-json/wp/v2/posts")
    //   .then(response => response.json())
    //   .then(posts => {
    //     this.setState({ posts: posts });
    //   });

    enquireScreen(b => {
      this.setState({ isMobile: !!b });
    });
    if (location.port) {
      setTimeout(() => {
        this.setState({
          show: true
        });
      }, 500);
    }
  }

  showModal = () => {
    console.log("I was called");
    this.setState({
      visible: true
    });
  };

  handleOk = () => {
    this.setState({ loading: true });
    setTimeout(() => {
      this.setState({ loading: false, visible: false });
    }, 3000);
  };

  handleCancel = () => {
    this.setState({ visible: false });
  };

  render() {
    const { visible, loading } = this.state;
    const children = [
      <Nav0
        id="Nav0_0"
        key="Nav0_0"
        dataSource={Nav00DataSource}
        isMobile={this.state.isMobile}
      />,
      <Banner0
        id="Banner0_1"
        key="Banner0_1"
        dataSource={Banner01DataSource}
        isMobile={this.state.isMobile}
      />,
      <Content0
        id="Content0_0"
        key="Content0_0"
        dataSource={Content00DataSource}
        isMobile={this.state.isMobile}
      />
    ];
    return (
      <div
        className="templates-wrapper"
        ref={d => {
          this.dom = d;
        }}
      >
        {this.state.show && children}
        {/* <Grid container spacing={2}>
          {this.state.posts.map((post, index) => (
            <Grid item xs={4} key={index}>
              <Card>
                <CardContent>
                  <Typography
                    color="textSecondary"
                    gutterBottom
                    dangerouslySetInnerHTML={{ __html: post.title.rendered }}
                  />
                  <Typography
                    variant="body2"
                    component="p"
                    dangerouslySetInnerHTML={{ __html: post.content.rendered }}
                  />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid> */}
        <Content style={{ padding: "0 50px" }}>
          <div className="site-layout-content" style={{ margin: "16px 0" }}>
            <Row gutter={[16, 16]}>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street One"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
              <Modal
                visible={visible}
                title="Property Evaluation"
                onOk={this.handleOk}
                onCancel={this.handleCancel}
                width={1000}
                footer={[
                  <Button key="back" onClick={this.handleCancel}>
                    Return
                  </Button>,
                  <Button
                    key="submit"
                    type="primary"
                    loading={loading}
                    onClick={this.handleOk}
                  >
                    Submit
                  </Button>
                ]}
              >
                <Descriptions title="Property Info" bordered>
                  <Descriptions.Item label="Property Type">
                    Commercial
                  </Descriptions.Item>
                  <Descriptions.Item label="Billing Mode">
                    Prepaid
                  </Descriptions.Item>
                  <Descriptions.Item label="Automatic Renewal">
                    YES
                  </Descriptions.Item>
                  <Descriptions.Item label="Built Around">
                    2014-04-24
                  </Descriptions.Item>
                  <Descriptions.Item label="Current Day" span={2}>
                    2020-10-03
                  </Descriptions.Item>
                  <Descriptions.Item label="Status" span={3}>
                    <Badge status="processing" text="Running" />
                  </Descriptions.Item>
                  <Descriptions.Item label="Negotiated Amount">
                    $100000.00
                  </Descriptions.Item>
                  <Descriptions.Item label="Tax Rebate">
                    $2000.00
                  </Descriptions.Item>
                  <Descriptions.Item label="Official Receipts">
                    $98000.00
                  </Descriptions.Item>
                  <Descriptions.Item label="Config Info">
                    Constructor: Arena Builders
                    <br />
                    Concept Type: High Rise
                    <br />
                    Availability: Yes
                    <br />
                    Available space: 4th, 5th , 6th Floor
                    <br />
                    Can Built Upto: 11
                    <br />
                    Region: Mumbai India <br />
                  </Descriptions.Item>
                </Descriptions>
              </Modal>

              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Two"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Three"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Four"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Five"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Five"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
            </Row>
            <Row gutter={[16, 16]}>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Seven"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Eight"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card
                  hoverable
                  style={{ width: 350, height: 400 }}
                  cover={
                    <img
                      alt="example"
                      src="https://cdn.pixabay.com/photo/2020/08/28/06/13/building-5523630_1280.jpg"
                    />
                  }
                  actions={[
                    <SettingOutlined key="setting" onClick={this.showModal} />,
                    <EditOutlined key="edit" />,
                    <EllipsisOutlined key="ellipsis" />
                  ]}
                >
                  <Meta
                    title="Property Street Nine"
                    description="www.instagram.com"
                  />
                </Card>
              </Col>
            </Row>
          </div>
        </Content>
        <Content5
          id="Content5_0"
          key="Content5_0"
          dataSource={Content50DataSource}
          isMobile={this.state.isMobile}
        />
        ,
        <Content3
          id="Content3_0"
          key="Content3_0"
          dataSource={Content30DataSource}
          isMobile={this.state.isMobile}
        />
        ,
        <Footer1
          id="Footer1_0"
          key="Footer1_0"
          dataSource={Footer10DataSource}
          isMobile={this.state.isMobile}
        />
      </div>
    );
  }
}
