import React from "react";
export const Nav00DataSource = {
  wrapper: { className: "header0 home-page-wrapper" },
  page: { className: "home-page" },
  logo: {
    className: "header0-logo",
    children:
      "https://www.freepnglogos.com/uploads/logo-home-png/logo-lake-county-home-show-april-lake-county-24.png"
  },
  Menu: {
    className: "header0-menu",
    children: [
      {
        name: "item0",
        className: "header0-item",
        children: {
          href: "#",
          children: [{ children: "Property Site First", name: "text" }]
        },
        subItem: [
          {
            name: "sub0",
            className: "item-sub",
            children: {
              className: "item-sub-item",
              children: [
                {
                  name: "image0",
                  className: "item-image",
                  children:
                    "https://gw.alipayobjects.com/zos/rmsportal/ruHbkzzMKShUpDYMEmHM.svg"
                },
                {
                  name: "title",
                  className: "item-title",
                  children: "Bangalore Urban"
                },
                {
                  name: "content",
                  className: "item-content",
                  children: "Property Site"
                }
              ]
            }
          },
          {
            name: "sub1",
            className: "item-sub",
            children: {
              className: "item-sub-item",
              children: [
                {
                  name: "image0",
                  className: "item-image",
                  children:
                    "https://gw.alipayobjects.com/zos/rmsportal/ruHbkzzMKShUpDYMEmHM.svg"
                },
                {
                  name: "title",
                  className: "item-title",
                  children: "Bangalore Rural"
                },
                {
                  name: "content",
                  className: "item-content",
                  children: "Property Website"
                }
              ]
            }
          }
        ]
      },
      {
        name: "item1",
        className: "header0-item",
        children: {
          href: "#",
          children: [{ children: "Property Site Second", name: "text" }]
        }
      },
      {
        name: "item2",
        className: "header0-item",
        children: {
          href: "#",
          children: [{ children: "Property Site Three", name: "text" }]
        }
      },
      {
        name: "item3",
        className: "header0-item",
        children: {
          href: "#",
          children: [{ children: "Property Site Four", name: "text" }]
        }
      }
    ]
  },
  mobileMenu: { className: "header0-mobile-menu" }
};
export const Banner01DataSource = {
  wrapper: { className: "banner0" },
  textWrapper: { className: "banner0-text-wrapper" },
  title: {
    className: "banner0-title",
    children: "Premier Real Estate Professionals."
  },
  content: {
    className: "banner0-content",
    children: "Bringing It All Together,Bringing REAL STATE Professionalism."
  },
  button: { className: "banner0-button", children: "Learn More" }
};
export const Content00DataSource = {
  wrapper: { className: "home-page-wrapper content0-wrapper" },
  page: { className: "home-page content0" },
  OverPack: { playScale: 0.3, className: "" },
  titleWrapper: {
    className: "title-wrapper",
    children: [{ name: "title", children: "REAL STATE SERVICES AND AMENTIES" }]
  },
  childWrapper: {
    className: "content0-block-wrapper",
    children: [
      {
        name: "block0",
        className: "content0-block",
        md: 8,
        xs: 24,
        children: {
          className: "content0-block-item",
          children: [
            {
              name: "image",
              className: "content0-block-icon",
              children:
                "https://zos.alipayobjects.com/rmsportal/WBnVOjtIlGWbzyQivuyq.png"
            },
            {
              name: "title",
              className: "content0-block-title",
              children: "One-stop businedd access"
            },
            {
              name: "content",
              children:
                "Four times the efficiency of payment, settlement, and accounting access products"
            }
          ]
        }
      },
      {
        name: "block1",
        className: "content0-block",
        md: 8,
        xs: 24,
        children: {
          className: "content0-block-item",
          children: [
            {
              name: "image",
              className: "content0-block-icon",
              children:
                "https://zos.alipayobjects.com/rmsportal/YPMsLQuCEXtuEkmXTTdk.png"
            },
            {
              name: "title",
              className: "content0-block-title",
              children: "One-stop in-event risk monitoring"
            },
            {
              name: "content",
              children:
                "Prior risk control and quality control capabilities in all requirements configuration links"
            }
          ]
        }
      },
      {
        name: "block2",
        className: "content0-block",
        md: 8,
        xs: 24,
        children: {
          className: "content0-block-item",
          children: [
            {
              name: "image",
              className: "content0-block-icon",
              children:
                "https://zos.alipayobjects.com/rmsportal/EkXWVvAaFJKCzhMmQYiX.png"
            },
            {
              name: "title",
              className: "content0-block-title",
              children: "One-stop data operation"
            },
            {
              name: "content",
              children:
                "Accumulate product access efficiency and operational efficiency data"
            }
          ]
        }
      }
    ]
  }
};
export const Content50DataSource = {
  wrapper: { className: "home-page-wrapper content5-wrapper" },
  page: { className: "home-page content5" },
  OverPack: { playScale: 0.3, className: "" },
  titleWrapper: {
    className: "title-wrapper",
    children: [
      {
        name: "title",
        children: "Exclusive Propertirs",
        className: "title-h1"
      },
      {
        name: "content",
        className: "title-content",
        children: "Best POSH properties available in the market."
      }
    ]
  },
  block: {
    className: "content5-img-wrapper",
    gutter: 16,
    children: [
      {
        name: "block0",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2018/05/08/13/44/architecture-3383067_1280.jpg"
          },
          content: { children: "Architecture Building" }
        }
      },
      {
        name: "block1",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2016/03/09/09/59/building-1245984_1280.jpg"
          },
          content: { children: "Glass Exterior Building" }
        }
      },
      {
        name: "block2",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2017/04/10/22/28/residence-2219972_1280.jpg"
          },
          content: { children: "High Residence Property" }
        }
      },
      {
        name: "block3",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2014/11/21/17/17/country-house-540796_1280.jpg"
          },
          content: { children: "Country Design" }
        }
      },
      {
        name: "block4",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2012/12/19/18/13/ancient-70996_1280.jpg"
          },
          content: { children: "Ancient Cottage" }
        }
      },
      {
        name: "block5",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2016/08/05/17/32/new-1572747_1280.jpg"
          },
          content: { children: "Green Field" }
        }
      },
      {
        name: "block6",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2015/11/07/11/54/barn-1031613_1280.jpg"
          },
          content: { children: "Farm House" }
        }
      },
      {
        name: "block7",
        className: "block",
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: "content5-block-content" },
          img: {
            children:
              "https://cdn.pixabay.com/photo/2020/07/09/06/13/garden-5385995_1280.jpg"
          },
          content: { children: "Green House" }
        }
      }
    ]
  }
};
export const Content30DataSource = {
  wrapper: { className: "home-page-wrapper content3-wrapper" },
  page: { className: "home-page content3" },
  OverPack: { playScale: 0.3 },
  titleWrapper: {
    className: "title-wrapper",
    children: [
      {
        name: "title",
        children: "We provides professional and competitive services",
        className: "title-h1"
      },
      {
        name: "content",
        className: "title-content",
        children:
          "Based on our indepth research, knowledge and powerful resources"
      }
    ]
  },
  block: {
    className: "content3-block-wrapper",
    children: [
      {
        name: "block0",
        className: "content3-block",
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: "content3-icon",
            children:
              "https://zos.alipayobjects.com/rmsportal/ScHBSdwpTkAHZkJ.png"
          },
          textWrapper: { className: "content3-text" },
          title: {
            className: "content3-title",
            children: "Types of Real Estate Investors"
          },
          content: {
            className: "content3-content",
            children:
              "Real Estate markets are extremely complicated. The price movements in this market are usually slow and difficult to come by. A major factor behind this is the type of investors who put their money in the real estate markets. Therefore, an understanding of the real estate markets has to be rooted in an understanding of the underlying participants as well as their motives."
          }
        }
      },
      {
        name: "block1",
        className: "content3-block",
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: "content3-icon",
            children:
              "https://zos.alipayobjects.com/rmsportal/NKBELAOuuKbofDD.png"
          },
          textWrapper: { className: "content3-text" },
          title: {
            className: "content3-title",
            children: "Real Estate Investing Myths"
          },
          content: {
            className: "content3-content",
            children:
              "Amongst all investment options available, real estate is the one that buyers tend to get emotionally attached with. For this reason, people rationalize their emotional decisions with the help of many myths about real estate investing. If one wants to avoid getting entangled in the emotional aspects of real estate investing and make financially sound decisions, it is imperative that these real estate myths be recognized and dismissed"
          }
        }
      },
      {
        name: "block2",
        className: "content3-block",
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: "content3-icon",
            children:
              "https://zos.alipayobjects.com/rmsportal/xMSBjgxBhKfyMWX.png"
          },
          textWrapper: { className: "content3-text" },
          title: {
            className: "content3-title",
            children: "Real Estate Investments: As Safe as Houses ?"
          },
          content: {
            className: "content3-content",
            children:
              "Investors usually refer to an extremely safe investment with the phrase “As Safe as Houses”. This shows the traditional mentality that real estate is one of the safest investment options. The old school chain of thought believes that real estate investing is largely risk-free and provides the best hedge against inflation. However, the world has recently discovered after multiple real estate crashes that the houses aren’t as safe as they were considered to be."
          }
        }
      },
      {
        name: "block3",
        className: "content3-block",
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: "content3-icon",
            children:
              "https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png"
          },
          textWrapper: { className: "content3-text" },
          title: {
            className: "content3-title",
            children: "Real Estate and Money Supply"
          },
          content: {
            className: "content3-content",
            children:
              "There is a direct relationship between the amount of money supply that is available in the system and the amount of money that finds its way into the real estate market. This is because real estate is one of the most preferred investment classes in the world. It is considered to be a safe haven and one of the safest hedges against inflation. However, very few people are aware of the fact that real estate also ends up creating more money supply! This is because of the way the modern fractional reserve banking system works. The more real estate is created, the more mortgage loans are made and the higher the money supply goes"
          }
        }
      },
      {
        name: "block4",
        className: "content3-block",
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: "content3-icon",
            children:
              "https://zos.alipayobjects.com/rmsportal/UsUmoBRyLvkIQeO.png"
          },
          textWrapper: { className: "content3-text" },
          title: {
            className: "content3-title",
            children: "Basic Ratio Analysis of Real Estate Investing"
          },
          content: {
            className: "content3-content",
            children:
              "Real estate investing is a sophisticated business. There are sophisticated techniques that are used by many diligent investors to carry out their due diligence. One such sophisticated technique is called ratio analysis. This technique is very similar to the ratio analysis that is carried out while evaluating the financial statements of publically listed corporations. However, there are certain idiosyncrasies and terms that are used only in real estate investments that form a part of this ratio analysis too. "
          }
        }
      },
      {
        name: "block5",
        className: "content3-block",
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: "content3-icon",
            children:
              "https://zos.alipayobjects.com/rmsportal/ipwaQLBLflRfUrg.png"
          },
          textWrapper: { className: "content3-text" },
          title: {
            className: "content3-title",
            children: "Transaction Costs in the Real Estate Market"
          },
          content: {
            className: "content3-content",
            children:
              "Flipping properties may sound like a good idea to the novice real estate investor. However, anyone who has even engaged in real estate transactions even once or twice knows that there are significant costs associated with real estate transactions. These costs are called “transaction costs” because they are triggered when a real estate transaction takes place. These costs tend to be significant and have the potential to burn a hole in your budget if they are not accounted for well in advance."
          }
        }
      }
    ]
  }
};
export const Footer10DataSource = {
  wrapper: { className: "home-page-wrapper footer1-wrapper" },
  OverPack: { className: "footer1", playScale: 0.2 },
  block: {
    className: "home-page",
    gutter: 0,
    children: [
      {
        name: "block0",
        xs: 24,
        md: 6,
        className: "block",
        title: {
          className: "logo",
          children:
            "https://www.freepnglogos.com/uploads/logo-home-png/logo-lake-county-home-show-april-lake-county-24.png"
        },
        childWrapper: {
          className: "slogan",
          children: [
            {
              name: "content0",
              children: "REAL STATE PREMIUM SERVICES AND CONSULTING"
            }
          ]
        }
      },
      {
        name: "block1",
        xs: 24,
        md: 6,
        className: "block",
        title: { children: "product" },
        childWrapper: {
          children: [
            { name: "link0", href: "#", children: "product" },
            { name: "link1", href: "#", children: "API" },
            { name: "link2", href: "#", children: "Quick start" },
            { name: "link3", href: "#", children: "Refrerence guide" }
          ]
        }
      },
      {
        name: "block2",
        xs: 24,
        md: 6,
        className: "block",
        title: { children: "on" },
        childWrapper: {
          children: [
            { href: "#", name: "link0", children: "FAQ" },
            { href: "#", name: "link1", children: "Contact us" }
          ]
        }
      },
      {
        name: "block3",
        xs: 24,
        md: 6,
        className: "block",
        title: { children: "Resources" },
        childWrapper: {
          children: [
            { href: "#", name: "link0", children: "Value Investing" },
            { href: "#", name: "link1", children: "Growth INvesting" }
          ]
        }
      }
    ]
  },
  copyrightWrapper: { className: "copyright-wrapper" },
  copyrightPage: { className: "home-page" },
  copyright: {
    className: "copyright",
    children: <span>Created Using Ant Design Framework and React</span>
  }
};
